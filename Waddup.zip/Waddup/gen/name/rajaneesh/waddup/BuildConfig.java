/** Automatically generated file. DO NOT MODIFY */
package name.rajaneesh.waddup;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}